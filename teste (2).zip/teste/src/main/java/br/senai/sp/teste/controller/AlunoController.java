package br.senai.sp.teste.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import br.senai.sp.teste.model.Produto;



	@Controller
	@RequestMapping ("/aluno")
	
	public class AlunoController {
		
		@GetMapping("/area")
		public String area(@RequestParam(name="nome")
		String nome,
		Model model) {
		
			System.err.println(nome);
			
			model.addAttribute("attrNome", nome);
			
			
			return "aluno/index3";
		}	
		
		 @GetMapping("/meuscursos")
		    public String meusCursos() {
		        return "aluno/meuscursos";
		    }
		}

	


