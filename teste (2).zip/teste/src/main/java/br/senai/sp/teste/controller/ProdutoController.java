package br.senai.sp.teste.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import br.senai.sp.teste.model.Produto;

@Controller
@RequestMapping ("/produto")
public class ProdutoController {
	
	
	@GetMapping()
	public String lista(Model model) {
		List<Produto> produto =new ArrayList<>();
		
		produto.add(new Produto(1L, "Furadeira", 100));
		produto.add(new Produto(2L, "XAXA", 100));
		produto.add(new Produto(1L, "XAXA", 120));


		return"produto/lista";
		
	}

	
	@GetMapping("/novo")
	public String novo(Model model)
	{
		model.addAttribute("produto", new Produto());
		return"produto/fmr-produto";
		
	}
	
	@PostMapping("gravar")
	public String gravar (Produto produto) {
		
	System.err.println(produto.getNome());
	System.err.println(produto.getPreco());
	return"home/index";
	
	
	
	

	}
}
